
## Available Scripts

In the project directory, you can run:

### `npm run preview`

Add input.mp4 file and transcript.json file in src/assets .\
This command will Open [http://localhost:3000](http://localhost:3000) which will preview your video in remotion studio .



### `npm run render`

It will render the video and create a out.mp4 file in public directory which will be our final video with animated captions.
### `npm start`

Builds the app for production to the `build` folder.\
A page with player will run in browser which will play your video crested using remotion

